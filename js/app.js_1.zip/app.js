// Client-side JavaScript for Apparels Collection App

// Configuration
const APP_CONFIG = {
    syncInterval: 300000,  // 5 minutes
    backupInterval: 300000, // 5 minutes
    cleanupDays: 2,        // days to keep data
    refreshInterval: 600000 // 10 minutes for page refresh
};

// Main App Class
class ApparelsCollectionApp {
    constructor() {
        this.isInitialized = false;
        this.pendingSyncKey = 'pending_sync_data';
        this.localBackupKey = 'local_backup';
    }

    // Initialize the application
    init() {
        if (this.isInitialized) return;
        
        document.addEventListener('DOMContentLoaded', () => {
            this.setupEventListeners();
            this.setupPeriodicTasks();
            this.setupUIComponents();
            this.cleanupOldData();
            this.checkOnlineStatus();
            
            // Initial sync if online
            if (navigator.onLine) {
                this.syncOfflineData();
            }
            
            this.isInitialized = true;
            console.log('App initialized successfully');
        });
    }

    // Setup all event listeners
    setupEventListeners() {
        window.addEventListener('online', () => this.handleOnlineStatus());
        window.addEventListener('offline', () => this.handleOfflineStatus());
    }

    // Setup periodic background tasks
    setupPeriodicTasks() {
        // Set up periodic local backup
        setInterval(() => this.saveLocalBackup(), APP_CONFIG.backupInterval);
        
        // Set up periodic sync check
        setInterval(() => this.syncOfflineData(), APP_CONFIG.syncInterval);
        
        // Set up periodic cleanup
        setInterval(() => this.cleanupOldData(), APP_CONFIG.syncInterval * 4); // Every 20 minutes
        
        // Auto-refresh dashboard if needed
        if (window.location.href.includes('dashboard.php')) {
            setInterval(() => location.reload(), APP_CONFIG.refreshInterval);
        }
    }

    // Setup UI components
    setupUIComponents() {
        this.setupHamburgerMenu();
        this.setupResponsiveTables();
        this.setupImagePreviews();
    }

    // Handle online status
    handleOnlineStatus() {
        console.log('Connection restored. Syncing data...');
        this.hideOfflineIndicator();
        this.syncOfflineData();
    }

    // Handle offline status
    handleOfflineStatus() {
        console.log('Offline mode detected.');
        this.showOfflineIndicator();
    }

    // Show offline indicator
    showOfflineIndicator() {
        if (document.getElementById('offline-indicator')) return;

        const offlineIndicator = document.createElement('div');
        offlineIndicator.id = 'offline-indicator';
        offlineIndicator.className = 'offline-indicator';
        offlineIndicator.textContent = '⚠️ Offline Mode Active';
        document.body.appendChild(offlineIndicator);
    }

    // Hide offline indicator
    hideOfflineIndicator() {
        const indicator = document.getElementById('offline-indicator');
        if (indicator) {
            indicator.remove();
        }
    }

    // Check initial online status
    checkOnlineStatus() {
        if (!navigator.onLine) {
            this.showOfflineIndicator();
        }
    }

    // Setup hamburger menu
    setupHamburgerMenu() {
        const hamburger = document.createElement('div');
        hamburger.className = 'hamburger';
        hamburger.innerHTML = '<span></span><span></span><span></span>';
        
        const headerLeft = document.querySelector('.header-left');
        if (headerLeft) {
            headerLeft.prepend(hamburger);
        }
        
        const sidebar = document.querySelector('.sidebar');
        const overlay = document.createElement('div');
        overlay.className = 'overlay';
        document.body.appendChild(overlay);
        
        // Toggle sidebar
        hamburger.addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleSidebar(hamburger, sidebar, overlay);
        });
        
        // Close sidebar when clicking outside
        overlay.addEventListener('click', () => {
            this.closeSidebar(hamburger, sidebar, overlay);
        });
        
        // Close sidebar when clicking on nav items
        const navItems = document.querySelectorAll('.nav-item');
        navItems.forEach(item => {
            item.addEventListener('click', () => {
                if (window.innerWidth < 992) {
                    this.closeSidebar(hamburger, sidebar, overlay);
                }
            });
        });
    }

    // Toggle sidebar
    toggleSidebar(hamburger, sidebar, overlay) {
        hamburger.classList.toggle('active');
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
    }

    // Close sidebar
    closeSidebar(hamburger, sidebar, overlay) {
        hamburger.classList.remove('active');
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    }

    // Setup responsive tables
    setupResponsiveTables() {
        const tables = document.querySelectorAll('table');
        tables.forEach(table => {
            const wrapper = document.createElement('div');
            wrapper.className = 'table-responsive';
            table.parentNode.insertBefore(wrapper, table);
            wrapper.appendChild(table);
            this.updateTableForMobile(table);
        });

        // Handle window resize
        window.addEventListener('resize', () => {
            tables.forEach(table => this.updateTableForMobile(table));
        });
    }

    // Update table for mobile view
    updateTableForMobile(table) {
        const isMobile = window.innerWidth < 768;
        const headers = table.querySelectorAll('th');
        const rows = table.querySelectorAll('tbody tr');
        
        if (isMobile) {
            headers.forEach((header, index) => {
                const headerText = header.textContent.trim();
                rows.forEach(row => {
                    const cell = row.children[index];
                    if (cell) {
                        cell.setAttribute('data-label', headerText);
                    }
                });
            });
        }
    }

    // Setup image previews
    setupImagePreviews() {
        document.addEventListener('change', (e) => {
            if (e.target.matches('input[type="file"][data-preview]')) {
                this.previewImages(e.target, e.target.dataset.preview);
            }
        });
    }

    // Preview images
    previewImages(input, containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        container.innerHTML = '';
        
        if (input.files) {
            Array.from(input.files).forEach(file => {
                const reader = new FileReader();
                
                reader.onload = (e) => {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.className = 'image-preview';
                    container.appendChild(img);
                };
                
                reader.readAsDataURL(file);
            });
        }
    }

    // Save local backup
    saveLocalBackup() {
        const userData = {
            timestamp: new Date().toISOString(),
            // Add other important data to backup
        };
        
        localStorage.setItem(this.localBackupKey, JSON.stringify(userData));
        console.log('Local backup saved at: ' + new Date().toLocaleTimeString());
    }

    // Sync offline data
    async syncOfflineData() {
        console.log('Checking for offline data to sync...');
        
        const pendingData = this.getPendingSyncData();
        
        if (pendingData.length > 0 && navigator.onLine) {
            console.log(`Found ${pendingData.length} items to sync`);
            
            for (const [index, item] of pendingData.entries()) {
                try {
                    const response = await fetch(item.url, {
                        method: item.method,
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(item.data)
                    });
                    
                    if (response.ok) {
                        pendingData.splice(index, 1);
                        this.savePendingSyncData(pendingData);
                        console.log('Data synced successfully:', item);
                    } else {
                        console.error('Sync failed for item:', item);
                    }
                } catch (error) {
                    console.error('Sync error:', error);
                }
            }
        }
    }

    // Queue data for sync
    queueForSync(url, method, data) {
        const pendingData = this.getPendingSyncData();
        pendingData.push({
            url,
            method,
            data,
            timestamp: new Date().toISOString()
        });
        this.savePendingSyncData(pendingData);
        console.log('Data queued for sync:', {url, method, data});
    }

    // Get pending sync data
    getPendingSyncData() {
        return JSON.parse(localStorage.getItem(this.pendingSyncKey)) || [];
    }

    // Save pending sync data
    savePendingSyncData(data) {
        localStorage.setItem(this.pendingSyncKey, JSON.stringify(data));
    }

    // Cleanup old data
    cleanupOldData() {
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - APP_CONFIG.cleanupDays);
        
        // Cleanup old backups
        const backup = localStorage.getItem(this.localBackupKey);
        if (backup) {
            try {
                const backupObj = JSON.parse(backup);
                const backupTime = new Date(backupObj.timestamp);
                
                if (backupTime < cutoffDate) {
                    localStorage.removeItem(this.localBackupKey);
                    console.log('Old backup data removed');
                }
            } catch (e) {
                console.error('Error parsing backup data:', e);
            }
        }
        
        // Cleanup old pending sync data
        const pendingData = this.getPendingSyncData();
        const filteredPendingData = pendingData.filter(item => {
            try {
                const itemTime = new Date(item.timestamp);
                return itemTime >= cutoffDate;
            } catch (e) {
                return false;
            }
        });
        
        if (filteredPendingData.length !== pendingData.length) {
            this.savePendingSyncData(filteredPendingData);
            console.log(`Cleaned up ${pendingData.length - filteredPendingData.length} old sync items`);
        }
    }

    // Simple data encryption (placeholder)
    encryptData(data, password) {
        console.log('Data would be encrypted with password:', password);
        return btoa(JSON.stringify(data));
    }

    // Simple data decryption (placeholder)
    decryptData(encryptedData, password) {
        try {
            return JSON.parse(atob(encryptedData));
        } catch (e) {
            console.error('Failed to decrypt data:', e);
            return null;
        }
    }
}

// Initialize the application
const app = new ApparelsCollectionApp();
app.init();