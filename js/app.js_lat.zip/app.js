// Client-side JavaScript for Apparels Collection App

// Configuration
const APP_CONFIG = {
    syncInterval: 300000,  // 5 minutes
    backupInterval: 300000, // 5 minutes
    cleanupDays: 2,        // days to keep data
    refreshInterval: 600000 // 10 minutes for page refresh
};

// Main App Class
class ApparelsCollectionApp {
    constructor() {
        this.isInitialized = false;
        this.pendingSyncKey = 'pending_sync_data';
        this.localBackupKey = 'local_backup';
    }

    // Initialize the application
    init() {
        if (this.isInitialized) return;
        
        document.addEventListener('DOMContentLoaded', () => {
            this.setupEventListeners();
            this.setupPeriodicTasks();
            this.setupUIComponents();
            this.cleanupOldData();
            this.checkOnlineStatus();
            
            // Initial sync if online
            if (navigator.onLine) {
                this.syncOfflineData();
            }
            
            this.isInitialized = true;
            console.log('App initialized successfully');
        });
    }

    // Setup all event listeners
    setupEventListeners() {
        window.addEventListener('online', () => this.handleOnlineStatus());
        window.addEventListener('offline', () => this.handleOfflineStatus());
    }

    // Setup periodic background tasks
    setupPeriodicTasks() {
        // Set up periodic local backup
        setInterval(() => this.saveLocalBackup(), APP_CONFIG.backupInterval);
        
        // Set up periodic sync check
        setInterval(() => this.syncOfflineData(), APP_CONFIG.syncInterval);
        
        // Set up periodic cleanup
        setInterval(() => this.cleanupOldData(), APP_CONFIG.syncInterval * 4); // Every 20 minutes
        
        // Auto-refresh dashboard if needed
        if (window.location.href.includes('dashboard.php')) {
            setInterval(() => location.reload(), APP_CONFIG.refreshInterval);
        }
    }

    // Setup UI components
    setupUIComponents() {
        this.setupHamburgerMenu();
        this.setupResponsiveTables();
        this.setupImagePreviews();
    }

    // Setup hamburger menu
   setupHamburgerMenu() {
        console.log('Setting up hamburger menu...');
        const hamburger = document.querySelector('.hamburger-menu');
        const sidebar = document.querySelector('.sidebar');
        let overlay = document.querySelector('.overlay');

        console.log('Elements:', {hamburger, sidebar, overlay});

        // Create overlay if it doesn't exist
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.className = 'overlay';
            document.body.appendChild(overlay);
            console.log('Created overlay');
        }

        if (!hamburger || !sidebar) {
            console.error('Hamburger or sidebar element not found');
            return;
        }

        // Toggle sidebar
        const toggleSidebar = () => {
            console.log('Toggling sidebar');
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
            document.body.classList.toggle('menu-open');
        };

        // Close sidebar
        const closeSidebar = () => {
            console.log('Closing sidebar');
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
            document.body.classList.remove('menu-open');
        };

        // Hamburger click
        hamburger.addEventListener('click', (e) => {
            e.stopPropagation();
            toggleSidebar();
        });

        // Overlay click
        overlay.addEventListener('click', closeSidebar);

        // Close when clicking on nav items (mobile)
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', () => {
                if (window.innerWidth <= 768) {
                    closeSidebar();
                }
            });
        });

        // Close when clicking outside (desktop)
        document.addEventListener('click', (e) => {
            if (window.innerWidth > 768 && 
                !sidebar.contains(e.target) && 
                !hamburger.contains(e.target) &&
                sidebar.classList.contains('active')) {
                closeSidebar();
            }
        });

        // Handle window resize
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768 && sidebar.classList.contains('active')) {
                closeSidebar();
            }
        });

        console.log('Hamburger menu setup complete');
    }
    // Setup responsive tables
    setupResponsiveTables() {
        const tables = document.querySelectorAll('table');
        tables.forEach(table => {
            // Check if table already has a wrapper
            if (table.parentElement.classList.contains('table-responsive')) {
                return;
            }
            
            const wrapper = document.createElement('div');
            wrapper.className = 'table-responsive';
            table.parentNode.insertBefore(wrapper, table);
            wrapper.appendChild(table);
            this.updateTableForMobile(table);
        });

        // Handle window resize
        window.addEventListener('resize', () => {
            tables.forEach(table => this.updateTableForMobile(table));
        });
    }

    // Update table for mobile view
    updateTableForMobile(table) {
        const isMobile = window.innerWidth < 768;
        const headers = table.querySelectorAll('th');
        const rows = table.querySelectorAll('tbody tr');
        
        headers.forEach((header, index) => {
            const headerText = header.textContent.trim();
            rows.forEach(row => {
                const cell = row.children[index];
                if (cell) {
                    if (isMobile) {
                        cell.setAttribute('data-label', headerText);
                    } else {
                        cell.removeAttribute('data-label');
                    }
                }
            });
        });
    }

    // Setup image previews
    setupImagePreviews() {
        document.addEventListener('change', (e) => {
            if (e.target.matches('input[type="file"][data-preview]')) {
                this.previewImages(e.target, e.target.dataset.preview);
            }
        });
    }

    // Preview images
    previewImages(input, containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        container.innerHTML = '';
        
        if (input.files) {
            Array.from(input.files).forEach(file => {
                const reader = new FileReader();
                
                reader.onload = (e) => {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.className = 'image-preview';
                    container.appendChild(img);
                };
                
                reader.readAsDataURL(file);
            });
        }
    }

    // Handle online status
    handleOnlineStatus() {
        console.log('Connection restored. Syncing data...');
        this.hideOfflineIndicator();
        this.syncOfflineData();
    }

    // Handle offline status
    handleOfflineStatus() {
        console.log('Offline mode detected.');
        this.showOfflineIndicator();
    }

    // Show offline indicator
    showOfflineIndicator() {
        if (document.getElementById('offline-indicator')) return;

        const offlineIndicator = document.createElement('div');
        offlineIndicator.id = 'offline-indicator';
        offlineIndicator.className = 'offline-indicator';
        offlineIndicator.textContent = '⚠️ Offline Mode Active';
        document.body.appendChild(offlineIndicator);
    }

    // Hide offline indicator
    hideOfflineIndicator() {
        const indicator = document.getElementById('offline-indicator');
        if (indicator) {
            indicator.remove();
        }
    }

    // Check initial online status
    checkOnlineStatus() {
        if (!navigator.onLine) {
            this.showOfflineIndicator();
        }
    }

    // Save local backup
    saveLocalBackup() {
        const userData = {
            timestamp: new Date().toISOString(),
            // Add other important data to backup
        };
        
        localStorage.setItem(this.localBackupKey, JSON.stringify(userData));
        console.log('Local backup saved at: ' + new Date().toLocaleTimeString());
    }

    // Sync offline data
    async syncOfflineData() {
        console.log('Checking for offline data to sync...');
        
        const pendingData = this.getPendingSyncData();
        
        if (pendingData.length > 0 && navigator.onLine) {
            console.log(`Found ${pendingData.length} items to sync`);
            
            // Create a copy of pending data to avoid modification during iteration
            const itemsToSync = [...pendingData];
            
            for (const item of itemsToSync) {
                try {
                    const response = await fetch(item.url, {
                        method: item.method,
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(item.data)
                    });
                    
                    if (response.ok) {
                        // Remove synced item from pending data
                        const index = pendingData.findIndex(i => i.timestamp === item.timestamp);
                        if (index !== -1) {
                            pendingData.splice(index, 1);
                            this.savePendingSyncData(pendingData);
                            console.log('Data synced successfully:', item);
                        }
                    } else {
                        console.error('Sync failed for item:', item);
                    }
                } catch (error) {
                    console.error('Sync error:', error);
                }
            }
        }
    }

    // Queue data for sync
    queueForSync(url, method, data) {
        const pendingData = this.getPendingSyncData();
        pendingData.push({
            url,
            method,
            data,
            timestamp: new Date().toISOString()
        });
        this.savePendingSyncData(pendingData);
        console.log('Data queued for sync:', {url, method, data});
    }

    // Get pending sync data
    getPendingSyncData() {
        return JSON.parse(localStorage.getItem(this.pendingSyncKey)) || [];
    }

    // Save pending sync data
    savePendingSyncData(data) {
        localStorage.setItem(this.pendingSyncKey, JSON.stringify(data));
    }

    // Cleanup old data
    cleanupOldData() {
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - APP_CONFIG.cleanupDays);
        
        // Cleanup old backups
        const backup = localStorage.getItem(this.localBackupKey);
        if (backup) {
            try {
                const backupObj = JSON.parse(backup);
                const backupTime = new Date(backupObj.timestamp);
                
                if (backupTime < cutoffDate) {
                    localStorage.removeItem(this.localBackupKey);
                    console.log('Old backup data removed');
                }
            } catch (e) {
                console.error('Error parsing backup data:', e);
            }
        }
        
        // Cleanup old pending sync data
        const pendingData = this.getPendingSyncData();
        const filteredPendingData = pendingData.filter(item => {
            try {
                const itemTime = new Date(item.timestamp);
                return itemTime >= cutoffDate;
            } catch (e) {
                return false;
            }
        });
        
        if (filteredPendingData.length !== pendingData.length) {
            this.savePendingSyncData(filteredPendingData);
            console.log(`Cleaned up ${pendingData.length - filteredPendingData.length} old sync items`);
        }
    }

    // Simple data encryption (placeholder)
    encryptData(data, password) {
        console.log('Data would be encrypted with password:', password);
        return btoa(JSON.stringify(data));
    }

    // Simple data decryption (placeholder)
    decryptData(encryptedData, password) {
        try {
            return JSON.parse(atob(encryptedData));
        } catch (e) {
            console.error('Failed to decrypt data:', e);
            return null;
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const logoImg = document.querySelector('.sidebar-logo > img');
    if (logoImg) {
        console.log('Logo image found:', logoImg);
        console.log('Computed width:', window.getComputedStyle(logoImg).width);
        console.log('Computed height:', window.getComputedStyle(logoImg).height);
        
        // Force reflow
        logoImg.style.display = 'none';
        logoImg.offsetHeight; // Trigger reflow
        logoImg.style.display = 'block';
    } else {
        console.error('Logo image not found!');
    }
});

setupPWAInstallPrompt() {
    let deferredPrompt;
    const installButton = document.getElementById('installButton');
    const installContainer = document.getElementById('installContainer');

    window.addEventListener('beforeinstallprompt', (e) => {
        // Prevent Chrome 67 and earlier from automatically showing the prompt
        e.preventDefault();
        // Stash the event so it can be triggered later
        deferredPrompt = e;
        
        // Show the install button
        if (installContainer) {
            installContainer.style.display = 'block';
        }

        // Handle install button click
        if (installButton) {
            installButton.addEventListener('click', () => {
                // Hide the install button
                installContainer.style.display = 'none';
                
                // Show the install prompt
                deferredPrompt.prompt();
                
                // Wait for the user to respond to the prompt
                deferredPrompt.userChoice.then((choiceResult) => {
                    if (choiceResult.outcome === 'accepted') {
                        console.log('User accepted the install prompt');
                    } else {
                        console.log('User dismissed the install prompt');
                    }
                    deferredPrompt = null;
                });
            });
        }
    });

    // Hide the install button when the app is successfully installed
    window.addEventListener('appinstalled', () => {
        if (installContainer) {
            installContainer.style.display = 'none';
        }
        console.log('App was successfully installed');
    });
}

// Initialize the application
const app = new ApparelsCollectionApp();
app.init();